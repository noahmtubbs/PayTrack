<?php
// Database connection details
$servername = "localhost";
$username = "root";  // Default username for MAMP
$password = "root";  // Leave blank if no password for root
$dbname = "PayTrack";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch users
$sql = "SELECT UserID, Username, Role FROM Users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List - PayTrack</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>User List</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
          
            </ul>
        </nav>
    </header>

    <div class="container">
        <section>
            <h2>Users</h2>
            <table class="grid-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Check if results exist and display them
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["UserID"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["Username"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["Role"]) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No users found</td></tr>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </section>
    </div>

    <footer>
        &copy; <?php echo date("Y"); ?> PayTrack. All rights reserved.
    </footer>
</body>
</html>
