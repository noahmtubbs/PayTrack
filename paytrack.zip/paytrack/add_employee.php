<?php
// Include the database connection
include('includes/db_connect.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $employee_type = $_POST['employee_type'];
    $department = $_POST['department'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];
    $hourly_rate = $_POST['hourly_rate'];
    $tax_rate = $_POST['tax_rate'];

    // Remove commas from salary and hourly rate (for decimal values)
    $salary = str_replace(',', '', $salary);
    $hourly_rate = str_replace(',', '', $hourly_rate);

    // Prepare SQL query to insert data into the Employee table
    $sql = "INSERT INTO Employee (FirstName, LastName, EmployeeType, Department, Position, Salary, HourlyRate, TaxRate) 
            VALUES ('$first_name', '$last_name', '$employee_type', '$department', '$position', '$salary', '$hourly_rate', '$tax_rate')";

    // Check if the query is successful
    if ($conn->query($sql) === TRUE) {
        echo "New employee added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Header and Navigation -->
    <header>
        <h1>Add New Employee</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="employee_list.php">Employee List</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
                <li><a href="delete_employee.php">Delete Employee</a></li>
                <li><a href="features.php">Features</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <!-- Add Employee Form -->
    <div class="container">
        <h2>Enter Employee Information</h2>
        <form method="POST" action="">
            <label for="first_name">First Name:</label><br>
            <input type="text" name="first_name" id="first_name" required><br><br>

            <label for="last_name">Last Name:</label><br>
            <input type="text" name="last_name" id="last_name" required><br><br>

            <label for="employee_type">Employee Type:</label><br>
            <input type="text" name="employee_type" id="employee_type" required><br><br>

            <label for="department">Department:</label><br>
            <input type="text" name="department" id="department" required><br><br>

            <label for="position">Position:</label><br>
            <input type="text" name="position" id="position" required><br><br>

            <label for="salary">Salary:</label><br>
            <input type="text" name="salary" id="salary" required><br><br>

            <label for="hourly_rate">Hourly Rate:</label><br>
            <input type="text" name="hourly_rate" id="hourly_rate"><br><br>

            <label for="tax_rate">Tax Rate:</label><br>
            <input type="text" name="tax_rate" id="tax_rate" required><br><br>

            <input type="submit" value="Add Employee">
        </form>
    </div>

</body>
</html>
