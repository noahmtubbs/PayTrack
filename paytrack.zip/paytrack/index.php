<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayTrack - Home</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to PayTrack</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if ($_SESSION['role'] === 'Admin'): ?>
                        <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
                    <?php else: ?>
                        <li><a href="employee_dashboard.php">Employee Dashboard</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="contact.php">Contact</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <div class="container">
        <section>
            <h2>About PayTrack</h2>
            <p>PayTrack is a robust payroll management system designed to simplify employee and payroll operations for businesses. Built with security, scalability, and efficiency in mind, PayTrack empowers businesses of all sizes.</p>
        </section>

        <section>
            <h2>Key Features</h2>
            <ul>
                <li><strong>Admin Control:</strong> Manage employees, payroll, and user accounts with full authority.</li>
                <li><strong>Employee Dashboard:</strong> Employees can securely access their payroll information.</li>
                <li><strong>Automated Payroll:</strong> Seamlessly calculate salaries, deductions, and bonuses.</li>
                <li><strong>Role-Based Access:</strong> Separate admin and employee dashboards for tailored experiences.</li>
                <li><strong>Secure Login:</strong> Role-based access ensures maximum data protection.</li>
            </ul>
        </section>

        <section>
            <h2>Get Started</h2>
            <?php if (isset($_SESSION['user_id'])): ?>
                <p>You are already logged in. Go to your dashboard:</p>
                <?php if ($_SESSION['role'] === 'Admin'): ?>
                    <a href="admin_dashboard.php" class="btn">Admin Dashboard</a>
                <?php else: ?>
                    <a href="employee_dashboard.php" class="btn">Employee Dashboard</a>
                <?php endif; ?>
            <?php else: ?>
                <p>Join the hundreds of businesses that trust PayTrack for their payroll management needs.</p>
                <a href="login.php" class="btn">Login</a>
            <?php endif; ?>
        </section>
    </div>

    <footer>
        &copy; <?php echo date("Y"); ?> PayTrack. All rights reserved.
    </footer>
</body>
</html>
