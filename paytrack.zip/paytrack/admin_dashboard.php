<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php"); // Redirect if not logged in or not an admin
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="register.php">Create Account</a></li>
                <li><a href="employee_list.php">Manage Employees</a></li>
                <li><a href="payroll_calculation.php">Calculate Payroll</a></li>
                <li><a href="payroll_history.php">View Payroll History</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <h2>Welcome, Admin <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>

        <section>
            <h3>Manage Users</h3>
            <ul>
                <li><a href="register.php">Create New User Account</a></li>
                <li><a href="user_list.php">View and Manage Users</a></li>
            </ul>
        </section>

        <section>
            <h3>Manage Employees</h3>
            <ul>
                <li><a href="add_employee.php">Add New Employee</a></li>
                <li><a href="employee_list.php">View Employee List</a></li>
                <li><a href="delete_employee.php">Remove Employees</a></li>
            </ul>
        </section>

        <section>
            <h3>View Payroll</h3>
            <ul>
                <li><a href="payroll_calculation.php">Calculate Payroll</a></li>
                <li><a href="payroll_history.php">View Payroll History</a></li>
            </ul>
        </section>
    </div>
</body>
</html>
