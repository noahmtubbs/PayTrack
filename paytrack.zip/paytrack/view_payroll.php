<?php
// Include the database connection
include('includes/db_connect.php');

// Start the session to get the logged-in user's employee ID
session_start();

// Ensure the user is logged in and has a valid employee ID in session
if (!isset($_SESSION['employee_id'])) {
    header("Location: login.php"); // Redirect to login if no session or employee ID is found
    exit();
}

$employee_id = $_SESSION['employee_id']; // Get the logged-in employee's ID from the session

// Fetch employee's first and last name
$sql_name = "SELECT FirstName, LastName FROM Employee WHERE EmployeeID = ?";
$stmt_name = $conn->prepare($sql_name);
$stmt_name->bind_param("i", $employee_id);
$stmt_name->execute();
$stmt_name->store_result();

if ($stmt_name->num_rows > 0) {
    $stmt_name->bind_result($first_name, $last_name);
    $stmt_name->fetch();
} else {
    $first_name = "Unknown";  // In case the name is not found
    $last_name = "Employee";
}

// Fetch payroll data for the specific employee
$sql = "SELECT * FROM Payroll WHERE EmployeeID = ? ORDER BY PayPeriodStart DESC"; // Filter by EmployeeID
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $employee_id); // Use the logged-in employee's ID
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Payroll History</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Payroll History</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                
            </ul>
        </nav>
    </header>

    <div class="container">
        <!-- Change the title here to include the employee's name -->
        <h2>Payroll for <?php echo $first_name . ' ' . $last_name; ?> Records</h2>
        
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            echo "<table border='1'>
                    <tr>
                        <th>Employee ID</th>
                        <th>Pay Period Start</th>
                        <th>Pay Period End</th>
                        <th>Base Salary</th>
                        <th>Hours Worked</th>
                        <th>Overtime Pay</th>
                        <th>Bonus</th>
                        <th>Tax Deduction</th>
                        <th>Pension Contribution</th>
                        <th>Benefits Contribution</th>
                        <th>Net Pay</th>
                    </tr>";

            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['EmployeeID'] . "</td>
                        <td>" . $row['PayPeriodStart'] . "</td>
                        <td>" . $row['PayPeriodEnd'] . "</td>
                        <td>" . number_format($row['BaseSalary'], 2) . "</td>
                        <td>" . number_format($row['HoursWorked'], 2) . "</td>
                        <td>" . number_format($row['OvertimePay'], 2) . "</td>
                        <td>" . number_format($row['Bonus'], 2) . "</td>
                        <td>" . number_format($row['Deductions'], 2) . "</td>
                        <td>" . number_format($row['PensionContribution'], 2) . "</td>
                        <td>" . number_format($row['BenefitsContribution'], 2) . "</td>
                        <td>" . number_format($row['NetPay'], 2) . "</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "No payroll records found for this employee.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
