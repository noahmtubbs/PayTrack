<?php
// Include the database connection
include('includes/db_connect.php');

// Fetch payroll data from the Payroll table
$sql = "SELECT * FROM Payroll ORDER BY PayPeriodStart DESC"; // Ordering by PayPeriodStart for recent first
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Payroll History</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Payroll History</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="employee_list.php">Employee List</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
                <li><a href="delete_employee.php">Delete Employee</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <h2>Payroll Records</h2>
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            echo "<table border='1'>
                    <tr>
                        <th>Employee ID</th>
                        <th>Pay Period Start</th>
                        <th>Pay Period End</th>
                        <th>Base Salary</th>
                        <th>Hours Worked</th>
                        <th>Overtime Pay</th>
                        <th>Bonus</th>
                        <th>Tax Deduction</th>
                        <th>Pension Contribution</th>
                        <th>Benefits Contribution</th>
                        <th>Net Pay</th>
                    </tr>";

            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['EmployeeID'] . "</td>
                        <td>" . $row['PayPeriodStart'] . "</td>
                        <td>" . $row['PayPeriodEnd'] . "</td>
                        <td>" . number_format($row['BaseSalary'], 2) . "</td>
                        <td>" . number_format($row['HoursWorked'], 2) . "</td>
                        <td>" . number_format($row['OvertimePay'], 2) . "</td>
                        <td>" . number_format($row['Bonus'], 2) . "</td>
                        <td>" . number_format($row['Deductions'], 2) . "</td>
                        <td>" . number_format($row['PensionContribution'], 2) . "</td>
                        <td>" . number_format($row['BenefitsContribution'], 2) . "</td>
                        <td>" . number_format($row['NetPay'], 2) . "</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "No payroll records found.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
