<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Employee') {
    header("Location: login.php"); // Redirect if not logged in or not an employee
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Employee Dashboard</h1>
        <nav>
            <ul>
                <li><a href="employee_dashboard.php">Dashboard</a></li>
                <li><a href="view_payroll.php">View My Payroll</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>

        <section>
            <h3>Your Payroll Information</h3>
            <p>View your latest payroll details:</p>
            <ul>
                <li><a href="view_payroll.php">View Payroll Details</a></li>
            </ul>
        </section>

        <section>
            <h3>Account Management</h3>
            <ul>
                <li><a href="update_account.php">Update Account Information</a></li>
                <li><a href="change_password.php">Change Password</a></li>
            </ul>
        </section>
    </div>
</body>
</html>
