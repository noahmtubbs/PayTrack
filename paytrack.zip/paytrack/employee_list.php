<?php
// Include the database connection
include('includes/db_connect.php');

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL query to fetch employees
$sql = "SELECT * FROM Employee";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PayTrack - Employee List">
    <title>Employee List</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Employee List</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="employee_list.php">Employee List</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
                <li><a href="delete_employee.php">Delete Employee</a></li>
                <li><a href="payroll_calculation.php">Payroll Calculation</a></li> 
                <li><a href="features.php">Features</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <h2>Employees</h2>
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            echo "<table><tr><th>Employee ID</th><th>Name</th><th>Department</th><th>Position</th><th>Salary</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["EmployeeID"] . "</td><td>" . $row["FirstName"] . " " . $row["LastName"] . "</td><td>" . $row["Department"] . "</td><td>" . $row["Position"] . "</td><td>" . $row["Salary"] . "</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No employees found.";
        }
        ?>
    </section>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
