<?php
// Include the database connection
include('includes/db_connect.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Employee List</title>
</head>
<body>
    <!-- Header and Navigation -->
    <header>
        <h1>Employee List</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
                <li><a href="delete_employee.php">Delete Employee</a></li>
                <li><a href="payroll_calculation.php">Payroll Calculation</a></li> 
            </ul>
        </nav>
    </header>

    <!-- Employee Table -->
    <div class="container">
        <h2>All Employees</h2>
        <table class="grid-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Employee Type</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Salary</th>
                    <th>Hourly Rate</th>
                    <th>Tax Rate</th>
                    <th>Hire Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetch employees from the database
                $sql = "SELECT EmployeeID, FirstName, LastName, EmployeeType, Department, Position, Salary, HourlyRate, TaxRate, HireDate FROM Employee";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['EmployeeID']}</td>
                                <td>{$row['FirstName']}</td>
                                <td>{$row['LastName']}</td>
                                <td>{$row['EmployeeType']}</td>
                                <td>{$row['Department']}</td>
                                <td>{$row['Position']}</td>
                                <td>{$row['Salary']}</td>
                                <td>{$row['HourlyRate']}</td>
                                <td>{$row['TaxRate']}</td>
                                <td>{$row['HireDate']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='10'>No employees found.</td></tr>";
                }

                // Close the connection
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
