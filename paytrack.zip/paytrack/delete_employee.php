<?php
// Include the database connection
include('includes/db_connect.php');

// Check if an employee is selected for deletion
if (isset($_POST['delete_employee'])) {
    $employee_id = $_POST['employee_id'];

    // Begin a transaction to ensure both DELETE queries succeed or fail together
    $conn->begin_transaction();

    try {
        // First, delete related records in the payroll table
        $sql = "DELETE FROM payroll WHERE EmployeeID = $employee_id";
        if ($conn->query($sql) === FALSE) {
            throw new Exception("Error deleting from payroll: " . $conn->error);
        }

        // Then, delete the employee record
        $sql = "DELETE FROM Employee WHERE EmployeeID = $employee_id";
        if ($conn->query($sql) === TRUE) {
            // Commit the transaction if both deletes were successful
            $conn->commit();
            echo "Employee deleted successfully.";
        } else {
            throw new Exception("Error deleting employee: " . $conn->error);
        }

    } catch (Exception $e) {
        // Rollback the transaction if any query fails
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}

// Fetch all employees
$sql = "SELECT EmployeeID, FirstName, LastName FROM Employee";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Employee</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to PayTrack</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="employee_list.php">Employee List</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
                <li><a href="delete_employee.php">Delete Employee</a></li>
                <li><a href="payroll_calculation.php">Payroll Calculation</a></li>
            </ul>
        </nav>
    </header>

    <h2>Delete Employee</h2>

    <!-- Form to delete employee -->
    <form method="POST" action="">
        <label for="employee_id">Select Employee to Delete:</label><br>
        <select name="employee_id" id="employee_id">
            <?php while ($row = $result->fetch_assoc()): ?>
                <option value="<?= $row['EmployeeID'] ?>">
                    <?= $row['FirstName'] ?> <?= $row['LastName'] ?>
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <input type="submit" name="delete_employee" value="Delete Employee">
    </form>
</body>
</html>
