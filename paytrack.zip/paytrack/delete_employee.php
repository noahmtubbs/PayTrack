<?php
// Include the database connection
include('includes/db_connect.php');

// Check if an employee is selected for deletion
if (isset($_POST['delete_employee'])) {
    $employee_id = $_POST['employee_id'];

    // SQL query to delete employee
    $sql = "DELETE FROM Employee WHERE EmployeeID = $employee_id";

    if ($conn->query($sql) === TRUE) {
        echo "Employee deleted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Fetch all employees
$sql = "SELECT EmployeeID, FirstName, LastName FROM Employee";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Employee</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Welcome to PayTrack</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="employee_list.php">Employee List</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
                <li><a href="delete_employee.php">Delete Employee</a></li>
                <li><a href="payroll_calculation.php">Payroll Calculation</a></li>
                <li><a href="features.php">Features</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <h2>Delete Employee</h2>

    <!-- Form to delete employee -->
    <form method="POST" action="">
        <label for="employee_id">Select Employee to Delete:</label><br>
        <select name="employee_id" id="employee_id">
            <?php while ($row = $result->fetch_assoc()): ?>
                <option value="<?= $row['EmployeeID'] ?>">
                    <?= $row['FirstName'] ?> <?= $row['LastName'] ?>
                </option>
            <?php endwhile; ?>
        </select><br><br>
        
        <label for="reason">Reason for Deletion:</label><br>
        <input type="text" name="reason" id="reason" required><br><br>

        <input type="submit" name="delete_employee" value="Delete Employee">
    </form>
</body>
</html>
