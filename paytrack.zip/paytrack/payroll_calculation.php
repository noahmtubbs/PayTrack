<?php
// Include the database connection
include('includes/db_connect.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST['employee_id'];
    $pay_period_start = $_POST['pay_period_start'];
    $pay_period_end = $_POST['pay_period_end'];

    // Fetch employee details from the Employee table
    $sql = "SELECT * FROM Employee WHERE EmployeeID = $employee_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $employee = $result->fetch_assoc();

        // Get the necessary data
        $annual_salary = $employee['Salary'];  // Annual salary from database
        $hourly_rate = $employee['HourlyRate'];
        $tax_rate = $employee['TaxRate'];
        $employee_type = $employee['EmployeeType'];
        $pension_contribution = 200;  // Fixed pension contribution
        $benefits_contribution_rate = 0.03; // 3% benefits contribution rate
        $bonus = $_POST['bonus'];  // Bonus from the form

        // Calculate the number of days in the pay period
        $start_date = new DateTime($pay_period_start);
        $end_date = new DateTime($pay_period_end);
        $interval = $start_date->diff($end_date);
        $days_in_period = $interval->days;

        // Calculate the yearly days (365 or 366 if leap year)
        $days_in_year = ($start_date->format('L') == 1) ? 366 : 365;

        // Calculate the proportion of the annual salary for the pay period
        $proportional_salary = ($annual_salary / $days_in_year) * $days_in_period;

        // Default overtime and hours worked
        $overtime_pay = 0;
        $hours_worked = 0;

        // If part-time, ask for hours worked
        if ($employee_type == "Part Time") {
            if (isset($_POST['hours_worked']) && is_numeric($_POST['hours_worked'])) {
                $hours_worked = $_POST['hours_worked']; // Assume this is entered in the form

                // Overtime if more than 40 hours worked
                if ($hours_worked > 40) {
                    $overtime_hours = $hours_worked - 40;
                    $overtime_pay = $overtime_hours * $hourly_rate * 1.5; // Overtime at 1.5x hourly rate
                }
            } else {
                // If no hours are entered, set hours worked to 0
                $hours_worked = 0;
            }
        }

        // Calculate deductions (e.g., tax)
        $tax_deduction = $proportional_salary * ($tax_rate / 100);

        // Calculate benefits contribution
        $benefits_contribution = $proportional_salary * $benefits_contribution_rate;

        // Calculate Net Pay
        $net_pay = $proportional_salary + $overtime_pay + $bonus - $tax_deduction - $pension_contribution - $benefits_contribution;

        // Insert payroll data into the Payroll table (if needed)
        $sql_insert = "INSERT INTO Payroll (EmployeeID, PayPeriodStart, PayPeriodEnd, BaseSalary, HoursWorked, OvertimePay, Bonus, Deductions, TaxRate, PensionContribution, BenefitsContribution, NetPay)
        VALUES ('$employee_id', '$pay_period_start', '$pay_period_end', '$annual_salary', '$hours_worked', '$overtime_pay', '$bonus', '$tax_deduction', '$tax_rate', '$pension_contribution', '$benefits_contribution', '$net_pay')";

        if ($conn->query($sql_insert) === TRUE) {
            echo "Payroll data inserted successfully.";
        } else {
            echo "Error: " . $sql_insert . "<br>" . $conn->error;
        }

    } else {
        echo "Employee not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payroll Calculation</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Header and Navigation -->
    <header>
        <h1>Payroll Details</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="employee_list.php">Employee List</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
                <li><a href="delete_employee.php">Delete Employee</a></li>
                <li><a href="features.php">Features</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <!-- Payroll Calculation Form -->
    <div class="container">
        <h2>Enter Pay Period Information</h2>
        <form method="POST" action="">
            <label for="employee_id">Employee ID:</label><br>
            <input type="number" name="employee_id" id="employee_id" required><br><br>

            <label for="pay_period_start">Pay Period Start:</label><br>
            <input type="date" name="pay_period_start" id="pay_period_start" required><br><br>

            <label for="pay_period_end">Pay Period End:</label><br>
            <input type="date" name="pay_period_end" id="pay_period_end" required><br><br>

            <label for="bonus">Bonus:</label><br>
            <input type="number" name="bonus" id="bonus" value="0" required><br><br>

            <!-- Ask for hours worked if part-time -->
            <?php if (isset($employee) && $employee['EmployeeType'] == 'Part Time'): ?>
                <label for="hours_worked">Hours Worked:</label><br>
                <input type="number" name="hours_worked" id="hours_worked" value="0" required><br><br>
            <?php endif; ?>

            <label for="overtime">Was Overtime Applied?</label><br>
            <select name="overtime" id="overtime">
                <option value="no">No</option>
                <option value="yes">Yes</option>
            </select><br><br>

            <input type="submit" value="Calculate Net Pay">
        </form>

        <!-- Display Payroll Details -->
        <?php if (isset($net_pay)): ?>
            <h3>Payroll Details for Employee ID: <?php echo $employee_id; ?></h3>
            <p><strong>Payroll ID:</strong> <?php echo $payroll_id; ?></p>
            <p><strong>Pay Period Start:</strong> <?php echo $pay_period_start; ?></p>
            <p><strong>Pay Period End:</strong> <?php echo $pay_period_end; ?></p>
            <p><strong>Base Salary (Annual):</strong> $ <?php echo number_format($annual_salary, 2); ?></p>
            <p><strong>Hours Worked:</strong> <?php echo number_format($hours_worked, 2); ?> hours</p>
            <p><strong>Overtime Pay:</strong> $ <?php echo number_format($overtime_pay, 2); ?></p>
            <p><strong>Bonus:</strong> $ <?php echo number_format($bonus, 2); ?></p>
            <p><strong>Pension Contribution:</strong> $ <?php echo number_format($pension_contribution, 2); ?></p>
            <p><strong>Tax Deduction:</strong> $ <?php echo number_format($tax_deduction, 2); ?></p>
            <p><strong>Benefits Contribution:</strong> $ <?php echo number_format($benefits_contribution, 2); ?></p>
            <h3><strong>Net Pay:</strong> $ <?php echo number_format($net_pay, 2); ?></h3>
        <?php endif; ?>
    </div>
</body>
</html>
