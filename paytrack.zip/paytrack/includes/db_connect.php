<?php
$servername = "localhost";
$username = "root";
$password = "root";  // Use your MySQL password for MAMP
$dbname = "PayTrack"; // Database you want to connect to

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, 3307); // Port number (3307) is included if necessary

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);  // Will show connection error if any
}

// Uncomment below for debugging purposes (optional)
// echo "Connected successfully to the database!";

// Close the connection after use to free up resources
// mysqli_close($conn);
?>
